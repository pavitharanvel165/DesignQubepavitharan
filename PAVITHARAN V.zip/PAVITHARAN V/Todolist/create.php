<html>
<head>
 <title>Create Todo list</title>
</head>
<body>
<h1>Create Todo List</h1>
<form method="post" action="create.php">
 <p>Todos: </p>
 <input name="todos" type="text">
 <p>Todo Comment: </p>
 <input name="comments" type="text">
 <p>User:</p>
 <input type="text" name="users">
 <br>
  <input type="submit" name="submit" value="submit">
</form>
 <?php
 require_once("db_connect.php");
if(isset($_POST['submit'])) {
$todos = $_POST['todos'];
$comments = $_POST['comments'];
$users = $_POST['users'];
     global $link;
     $link=OpenCon();
     $query = "INSERT INTO todo(todos, comments, users) VALUES ('$todos', '$comments', '$users' )";
    $insertTodo = mysqli_query($link, $query);
    if($insertTodo){
        echo “successfully”;
    }else{
        echo mysqli_error($link);
    }
    mysqli_close($link);
}
?>
</body>
</html>
