
function save_options() 
{
	
	console.log("Saving...");
	
	var updatedBlockedSites = document.getElementById('blockedSites').value;
	
	chrome.storage.sync.set(
	{
		blockedSites: updatedBlockedSites
	}
	, function() 
	{
		var status = document.getElementById('status');
		status.textContent = 'Options saved.';
		setTimeout(function() 
		{
			status.textContent = '';
		}, 
		750);
	});
}

function restore_options() 
{
	chrome.storage.sync.get(
	{
		blockedSites: 'facebook.com\nfacebook.net\nplus.google.com\ntwitter.com'
	}
	, function(items) 
	{
		document.getElementById('blockedSites').value = items.blockedSites;
	});
}

document.addEventListener('DOMContentLoaded', restore_options);

document.getElementById('save').addEventListener('click', save_options);