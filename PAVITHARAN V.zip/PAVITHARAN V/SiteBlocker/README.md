SiteBlocker
===========

Google Chrome extension to block pre-defined websites.  Visit the Chrome Web Store for more details: https://chrome.google.com/webstore/detail/site-blocker/gopdhjgleldiggmgblgejlbccplechjc?hl=en-US.
